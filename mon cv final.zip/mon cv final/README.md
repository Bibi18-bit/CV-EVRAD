# CV de Djoumetio Donfack Evrad

Ce projet contient un CV au format HTML et Bootstrap, permettant une consultation facile et responsive.

##  Prérequis

Pour afficher correctement le CV, vous avez besoin :
- D'un *navigateur web* moderne (Google Chrome, Firefox, Edge, Safari, etc.)
- D'une *connexion Internet* (pour charger Bootstrap et FontAwesome)

##  Structure du projet

- index.html → Fichier principal contenant le CV
- evrad.jpg → Image de profil (à remplacer par votre propre photo)
- README.md → Ce fichier d'explication

##  Comment consulter le CV ?

###  Sur un ordinateur :
1. Téléchargez les fichiers du projet.
2. Ouvrez index.html dans un navigateur.

###  Sur un téléphone :
1. Envoyez le fichier index.html sur votre mobile.
2. Ouvrez-le avec un navigateur web.

###  Hébergement en ligne (optionnel) :
Pour partager le CV en ligne, vous pouvez utiliser :
- [GitHub Pages](https://pages.github.com/)

##  Technologies utilisées
- *HTML5*
- *CSS3*
- *Bootstrap 5*
- *FontAwesome*

##  Contact
*Djoumetio Donfack Evrad*  
📞 017625122642  
✉ evraddjoumetio18@gmail.com  
📍 Saarbrücken, Allemagne